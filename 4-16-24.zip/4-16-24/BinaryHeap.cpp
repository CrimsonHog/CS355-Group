#ifndef _BINARYHEAP_CPP
#define _BINARYHEAP_CPP

#include <iostream>
#include <fstream>
#include <vector>
#include "BinaryHeap.h"
using namespace std;

/*
	Function Name: BinaryHeap
	Function Inputs: N/A
	Function Outputs: N/A
	Function Description: Default Constructor for the BinaryHeap, not good to use since we need to initialize the heap with a node from the graph
	Author: Kelson
	Testers:
*/
BinaryHeap::BinaryHeap()
{
	cout << "Please dont use this constructor, pass in a Graph" << endl;
}

/*
	Function Name: BinaryHeap
	Function Inputs: Graph theGraph: This is the graph that holds all of our data
	Function Outputs: N/A
	Function Description: will intialize the implicit vector of the heap with the origin node of the graph
	Author: Kelson
	Testers:
*/
BinaryHeap::BinaryHeap(Graph theGraph)
{
	cout << "Heap parametered constructor" << endl;
	heap.push_back(theGraph.GetNode(0)); //set the index being passed in to whatever the origin node of the graph will be
	cout << heap.size()<< endl;
//	heap.push_back(theGraph.GetNode(1));
//	heap.push_back(theGraph.GetNode(2));
//	heap.push_back(theGraph.GetNode(3));
//	heap.push_back(theGraph.GetNode(4));
//	heap.push_back(theGraph.GetNode(5));
//	heap.push_back(theGraph.GetNode(6));
//	heap.push_back(theGraph.GetNode(7));
//	heap.push_back(theGraph.GetNode(8));
//	heap.push_back(theGraph.GetNode(9));
//	heap.push_back(theGraph.GetNode(10));
}


/*
	Function Name: PercolateUp
	Function Inputs: GraphNode newNode
	Function Outputs: N/A
	Function Description: 
	Author: Ethan / Kelson
	Testers: Kelson Moore
*/
void BinaryHeap::PercolateUp(int index)
{
	cout << endl << "Entering PercolateUp in BinaryHeap.cpp" << endl;
	cout << "Next Node: " << heap[index].GetName() << endl;
	cout << "Next Node's Weight: " << heap[index].GetWeight() << endl;
	cout << "Next Node's Edge Count: " << heap[index].GetEdgeAmount() << endl;
	cout << "Parent Node: " << heap[(index - 1) / 2].GetName() << endl;
	cout << "Parent Node's Weight: " << heap[(index - 1) / 2].GetWeight() << endl;
	cout << "Parent Node's Edge Count: " << heap[(index - 1) / 2].GetEdgeAmount() << endl;
	cout << "root: " << heap[0].GetName() << endl;
	cout << "root Weight: " << heap[0].GetWeight() << endl << endl;

	cout << "BinaryHeap: Starting Index is: " << index << endl;
	
	if(heap.size() > 1)
	{
		cout << "BinaryHeap: Heap has more than one val" << endl;
		while(heap[index].GetWeight() < heap[(index - 1) / 2].GetWeight() ) //&& ((index - 1) / 2) >= 1)
		{
			cout << "Swap is being made" << endl;
			//swap the newNode and parent
			GraphNode temp = heap[index];
			heap[index] = heap[(index - 1) / 2];
			heap[(index - 1) / 2] = temp;
			//update the index
			index = (index - 1) / 2;
		}
	}
/*	else
	{
		return;
	}
*/
	
	cout << "That node was moved to index: " << index << endl;
	cout << "The root node is: " << heap[0].GetName() << endl;
	cout << "RootNode edge count is: " << heap[0].GetEdgeAmount() << endl;
//	cout << "After PercolateUp while loop" << endl;
}

/*
	Function Name: PercolateDown
	Function Inputs: GraphNode newNode
	Function Outputs: N/A
	Function Description: 
	Author: Ethan / Kelson / Gage
	Testers:
*/
/*
void BinaryHeap::PercolateDown(int index)
{
	int leftChildIndex = 2 * index + 1;

	while(leftChildIndex < heap.size())
	{
		int rightChildIndex = 2 * index + 2;
		int minimumIndex = leftChildIndex; // assume minimum child is left child before finding

		if (rightChildIndex < heap.size()) // be sure right child doesn't go beyond bounds of heap
		{
			if (heap[rightChildIndex].GetWeight() < heap[minimumIndex].GetWeight()) // checks if right child is less than current min
			{
				minimumIndex = rightChildIndex;
			}
		}

		if (heap[index].GetWeight() <= heap[minimumIndex].GetWeight())
		{
			return; // minimum heap is good
		}
		else
		{
			GraphNode temp = heap[index];
			heap[index] = heap[minimumIndex];
			heap[minimumIndex] = temp;
			index = minimumIndex;
			leftChildIndex = 2 * index + 1;
		}
	}
}
*/
void BinaryHeap::PercolateDown(int index)
{
	int leftChildIndex = (2 * index) + 1;
	int rightChildIndex = (2 * index) + 2;
	int minimumIndex; //left uninitialized at first on purpose
	
	//checks to make sure the left && right child is still in bounds of the array && wheather either child is smaller than the index
	while(rightChildIndex < heap.size() && (heap[leftChildIndex].GetWeight() < heap[index].GetWeight() || heap[rightChildIndex].GetWeight() < heap[index].GetWeight()))
	{
		if(leftChildIndex > heap.size())
		{
			return;
		}
		else
		{
			if(heap[leftChildIndex].GetWeight() < heap[rightChildIndex].GetWeight()) //checks to see which child is smaller
				minimumIndex = leftChildIndex;
			else
				minimumIndex = rightChildIndex;
				
			GraphNode tempNode = heap[index]; //sets tempnode to whatever the parent Node is
			heap[index] = heap[minimumIndex]; //sets the index to whatever child was smaller
			heap[minimumIndex] = tempNode; //moves the parent node down to where ever the smaller value was
			
			index = minimumIndex;
			leftChildIndex = (2 * index) + 1;
			rightChildIndex = (2 * index) + 2;
		}
	}
}

/*
	Function Name: Insert
	Function Inputs: 
	Function Outputs: N/A
	Function Description: Insert into node array and percolate up to make sure any new node is in the correct position
	Author: Ethan / Kelson
	Testers:
*/
void BinaryHeap::Insert(GraphNode newNode)
{
	cout << endl << "Entering Insert in BinaryHeap.cpp" << endl;
	cout << "Heap size upon enter: " << heap.size() << endl;
	heap.push_back(newNode);
	cout << "Heap size after insertion: " << heap.size() << endl;
	cout << "All the values in the heap are:" << endl;
	for(int i = 0; i < heap.size(); i++)
	{
		cout << heap[i].GetName() << endl;
		cout << "\tWeight: " << heap[i].GetWeight() << endl;
		cout << "\tEdge Count: " << heap[i].GetEdgeAmount() << endl;
	}
	cout << endl;
	PercolateUp(heap.size() - 1); //we need to do the -1 since the value we just inserted is at the INDEX below the SIZE of the vector
//	cout << "Heap size is now: " << heap.size() << endl;
}

/*
	Funtion Name: Remove
	Function Inputs: GraphNode factor[], int val
	Function Outputs: N/A
	Function Description: Remove the root node from the array and percolate down to make sure the array is in the correct order
	Author: Ethan / Kelson
	Testers: 
*/
GraphNode BinaryHeap::Remove()
{
	GraphNode minValue = heap[0];
	GraphNode newValue = heap[heap.size() - 1];
	cout << "Heap size is: " << heap.size() << endl;
	heap.pop_back(); 
	cout << "After pop size is: " << heap.size() << endl;

	if (heap.size() > 0)
	{
		heap[0] = newValue;
		PercolateDown(0);
	}
	
	cout << "New min val is: " << heap[0].GetName() << endl;

	cout << "BinaryHeap.cpp::Remove(): Minvalue edgeCount: " << minValue.GetEdgeAmount() << endl;
	return minValue;
}

int BinaryHeap::GetSize()
{
	return heap.size();
}

GraphNode BinaryHeap::GetNode(int index)
{
	return heap[index];
}

bool BinaryHeap::Empty()
{
	bool empty = false;

	if (heap.size() == 0)
	{
		empty = true;
	}

	return empty;
}

void BinaryHeap::Heapify()
{
	int i = heap.size() / 2 - 1; // calculates parent node index

	while (i >= 0)
	{
		PercolateDown(i);
		i--;
	}

	i = heap.size() - 1;

	while (i > 0)
	{
		// swap heap[0] and heap[i]
		GraphNode temp = heap[0];
		heap[0] = heap[i];
		heap[i] = temp;

		PercolateDown(0);
		i--;
	}

	for (int i = 0; i < heap.size(); i++)
	{
		cout << "Name: " << heap[i].GetName() << endl;
		cout << "Weight: " << heap[i].GetWeight() << endl;
	}
}

#endif
